const utilsData = (function() {
  return {
    enterMode: function(drawingData, scene, mode){
      switch(mode){
        case "removeMode":
          drawingData.removeMode = true;
          drawingData.finMode = false;
          drawingData.bodyMode = false;
          drawingData.tornadoMode = false;
          drawingData.addSharkMode = false;
          document.getElementById("AffichageMode").innerHTML = "Clique sur un objet pour l'effacer";
        break;
        case "finMode":
          drawingData.removeMode = false;
          drawingData.finMode = true;
          drawingData.bodyMode = false;
          drawingData.tornadoMode = false;
          drawingData.addSharkMode = false;
          document.getElementById("AffichageMode").innerHTML = "Dessine la forme d'une nageoire";
        break;
        case "bodyMode":
          drawingData.removeMode = false;
          drawingData.finMode = false;
          drawingData.bodyMode = true;
          drawingData.tornadoMode = false;
          drawingData.addSharkMode = false;
          document.getElementById("AffichageMode").innerHTML = "Dessine le corps du requin";
          utilsData.reinitPlane(drawingData, scene);
        break;
        case "tornadoMode":
          // on va dessiner la tornade
          if(!drawingData.tornadoMode){
            drawingData.removeMode = false;
            drawingData.finMode = false;
            drawingData.bodyMode = false;
            drawingData.tornadoMode = true;
            drawingData.addSharkMode = false;
            document.getElementById("AffichageMode").innerHTML = "Dessine la forme de la tornade";
            // sauvegarde du requin
            drawingData.sharkTab.push(drawingData.body);
            // reinitialisation a la scene vide
            scene.remove(drawingData.body);
            drawingData.body = null;

            // si on avait deja dessine une tornade
            if(drawingData.tornado != null){
              scene.add(drawingData.tornado);
            }
          }
          // on dessine un nouveau requin
          else{
            drawingData.removeMode = false;
            drawingData.finMode = false;
            drawingData.bodyMode = true;
            drawingData.tornadoMode = false;
            drawingData.addSharkMode = false;
            document.getElementById("AffichageMode").innerHTML = "Dessine un nouveau requin";
            // reinitialisation a la scene vide
            scene.remove(drawingData.tornado);
          }
        break;
        case "addSharkMode":
          drawingData.removeMode = false;
          drawingData.finMode = false;
          drawingData.bodyMode = false;
          drawingData.tornadoMode = false;
          drawingData.addSharkMode = true;
          document.getElementById("AffichageMode").innerHTML = "Place ton requin dans la tornade";
          // on place le premier requin du tableau dans la main de l'utilisateur
          drawingData.currentShark = drawingData.sharkTab.pop();
          drawingData.currentShark.scale.set(1/4, 1/4, 1/4);
          drawingData.tornado.add(drawingData.currentShark);
        break;
      }
    },

    removeLines: function(drawingData, scene) {
      const lineTab = drawingData.lineTab;
      for(let i = 0; i < lineTab.length; i++){
        scene.remove(lineTab[i]);
      }
      drawingData.lineTab = [];
    },

    alignPlaneCamera: function(drawingData, camera, scene) {
      drawingData.plane.quaternion.copy(camera.quaternion);
      drawingData.plane.position.set(0,0,0);
    },

    // remet le plan de dessin a sa position initiale
    reinitPlane: function(drawingData, scene) {
      identityQ = new THREE.Quaternion(1,0,0,0);
      drawingData.plane.quaternion.copy(identityQ);
      drawingData.plane.position.set(0,0,0);
    },

    addLine: function(drawingData, scene){
      const lineGeometry = new THREE.Geometry();
      lineGeometry.vertices = drawingData.drawing3DPoints;
      const lineMaterial = new THREE.LineBasicMaterial( { color: 0xff00ff } );
      drawingData.line = new THREE.Line( lineGeometry, lineMaterial );
      drawingData.lineTab.push(drawingData.line);
      drawingData.line.is_ob = true;
      scene.add(drawingData.line);
    },
  };
})();
