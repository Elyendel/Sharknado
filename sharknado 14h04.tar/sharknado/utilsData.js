const utilsData = (function() {
  return {
    enterMode: function(drawingData, scene, mode){
      switch(mode){
        case "removeMode":
          drawingData.removeMode = true;
          drawingData.finMode = false;
          drawingData.bodyMode = false;
          drawingData.tornadoMode = false;
        break;
        case "bodyMode":
          drawingData.removeMode = false;
          drawingData.finMode = false;
          drawingData.bodyMode = true;
          drawingData.tornadoMode = false;
        break;
        case "finMode":
          drawingData.removeMode = false;
          drawingData.finMode = true;
          drawingData.bodyMode = false;
          drawingData.tornadoMode = false;
        break;
        case "bodyMode":
          drawingData.removeMode = false;
          drawingData.finMode = false;
          drawingData.bodyMode = true;
          drawingData.tornadoMode = false;
        break;
        case "tornadoMode":
          // on va dessiner la tornade
          if(!drawingData.tornadoMode){
            drawingData.removeMode = false;
            drawingData.finMode = false;
            drawingData.bodyMode = false;
            drawingData.tornadoMode = true;
            // sauvegarde du requin
            drawingData.sharkTab.push(drawingData.body);
            // reinitialisation a la scene vide
            scene.remove(drawingData.body);
            utilsData.reinit(scene,drawingData);
          }
          // on dessine un nouveau requin
          else{
            drawingData.removeMode = false;
            drawingData.finMode = false;
            drawingData.bodyMode = true;
            drawingData.tornadoMode = false;
            // sauvegarde de la tornade
            drawingData.tornado = drawingData.drawingObjects[1];
            // reinitialisation a la scene vide
            scene.remove(drawingData.tornado);
            utilsData.reinit(scene, drawingData);
          }

        break;
      }
    },

    // on retire tous les objets sauf le plan de dessin
    reinit: function(drawingData, scene){
      for(int k=1; k < drawingData.drawingObjects.length; k++){
        drawingData.drawingObjects.pop();
      }
    },

    removeLines: function(drawingData, scene) {
      const lineTab = drawingData.lineTab;
      for(let i = 0; i < lineTab.length; i++){
        scene.remove(lineTab[i]);
      }
      drawingData.lineTab = [];
    },

    addLine: function(drawingData, scene){
      const lineGeometry = new THREE.Geometry();
      lineGeometry.vertices = drawingData.drawing3DPoints;
      const lineMaterial = new THREE.LineBasicMaterial( { color: 0xff00ff } );
      drawingData.line = new THREE.Line( lineGeometry, lineMaterial );
      drawingData.lineTab.push(drawingData.line);
      drawingData.line.is_ob = true;
      scene.add(drawingData.line);
    },
  };
})();
