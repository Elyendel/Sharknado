"use strict";

const mouseEvents = (function() {

  return {

    onMouseDown: function(event, scene, camera, raycaster, screenSize, drawingData) {

      if( event.button == 0 ) { // activation si la click gauche est enfoncé
        // Coordonnées du clic de souris
        const xPixel = event.clientX;
        const yPixel = event.clientY;

        const x =  2*xPixel/screenSize.w-1;
        const y = -2*yPixel/screenSize.h+1;

        utilsDrawing.find3DPoint(raycaster, camera, x ,y, drawingData,scene, true);
        drawingData.enableDrawing = true;
      }

    },

    onMouseMove: function( event, scene, camera, raycaster, screenSize, drawingData){
      // Coordonnées de la position de la souris
      const xPixel = event.clientX;
      const yPixel = event.clientY;

      const x =  2*xPixel/screenSize.w-1;
      const y = -2*yPixel/screenSize.h+1;

      utilsDrawing.updateShape(raycaster, camera, x ,y, drawingData,scene, true);

      if (drawingData.enableDrawing == true){
        utilsDrawing.find3DPoint(raycaster, camera, x ,y, drawingData,scene, false);
      }

    },

    onMouseUp: function(event, scene, drawingData) {
      drawingData.enableDrawing = false;

      if (drawingData.drawing3DPoints.length > 0){

        drawingData.selectedObject.updateMatrix();
        const matrice = drawingData.selectedObject.matrix;
        matrice.getInverse(matrice);
        drawingData.line.applyMatrix(matrice);

        scene.remove(drawingData.line);
        drawingData.selectedObject.add(drawingData.line);
        drawingData.drawing3DPoints = [];
      }

      var extrudeSettings = {
	       steps: 2,
	        depth: 16,
	         bevelEnabled: true,
	          bevelThickness: 1,
	           bevelSize: 1,
	            bevelOffset: 0,
	             bevelSegments: 1
      };


      var geometry = new THREE.ExtrudeGeometry( drawingData.currentShape, extrudeSettings );
      var material = new THREE.MeshBasicMaterial( { color: 0xffff00 } );
      var mesh = new THREE.Mesh( geometry, material ) ;

      // update de la scene
      scene.add( mesh );
      drawingData.drawingObjects.push(mesh);
      // reinitalisation
      drawingData.currentShape = new THREE.Shape();
    },

  };
})();
