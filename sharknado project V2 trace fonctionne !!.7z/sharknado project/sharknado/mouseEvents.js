"use strict";

const mouseEvents = (function() {

  return {

    onMouseDown: function(event, scene, camera, raycaster, screenSize, drawingData) {
      if( event.button == 0 ) { // activation si la click gauche est enfoncé
        // Coordonnées du clic de souris
        const xPixel = event.clientX;
        const yPixel = event.clientY;

        const x =  2*xPixel/screenSize.w-1;
        const y = -2*yPixel/screenSize.h+1;

        if(drawingData.bodyMode) {
          utilsDrawing.find3DPoint(raycaster, camera, x ,y, drawingData,scene, true);
          drawingData.enableDrawing = true;
        }
      //clic droit : rotation




      }
    },

    onMouseMove: function( event, scene, camera, raycaster, screenSize, drawingData){
      // Coordonnées de la position de la souris
      const xPixel = event.clientX;
      const yPixel = event.clientY;

      const x =  2*xPixel/screenSize.w-1;
      const y = -2*yPixel/screenSize.h+1;






      if(drawingData.bodyMode) {
        if (drawingData.enableDrawing == true){
          utilsDrawing.find3DPoint(raycaster, camera, x ,y, drawingData,scene, false);
        }
      }



    },

    onMouseUp: function( event, scene, camera, raycaster, screenSize, drawingData) {
      const xPixel = event.clientX;
      const yPixel = event.clientY;

      const x =  2*xPixel/screenSize.w-1;
      const y = -2*yPixel/screenSize.h+1;

      //actualisation de la position du plan de dessin
      drawingData.drawingObjects[0].quaternion.copy(camera.quaternion);

      if(drawingData.bodyMode) {
        drawingData.enableDrawing = false;

        //drawingData.currentShape = new THREE.Shape(drawingData.drawing3DPoints);

        const epaisseur = 10;



        // rotation pour mettre l'objet a extruder dans le bon plan Oxy

        // origine du repere local
        const p0 = drawingData.drawing3DPoints[0].clone();
        const p1 = drawingData.drawing3DPoints[Math.floor(drawingData.drawing3DPoints.length /2)].clone();

        // un vecteur du plan
        const u1 = new THREE.Vector3(p1.x - p0.x, p1.y - p0.y, p1.z - p0.z);
        u1.normalize();
        console.log(u1);

        // vecteur orthogonal au plan
        const n = camera.getWorldDirection().clone().multiplyScalar(-1);
        n.normalize();
        console.log(n)

        const u2= new THREE.Vector3(0,0,0);
        u2.crossVectors(n, u1);
        u2.normalize()
        console.log(u2);

        const M = new THREE.Matrix3();
        M.set(u1.x, u1.y, u1.z,
              u2.x, u2.y, u2.z,
              n.x, n.y,n.z)


        const tab = []
        for (let v = 0; v < drawingData.drawing3DPoints.length; v++){
          tab.push(drawingData.drawing3DPoints[v].clone().sub(p0).applyMatrix3(M))
        }

        drawingData.currentShape = new THREE.Shape(tab);
        var extrudeSettings = {
           bevelEnabled:false, amount: epaisseur,
        };

        var geometry = new THREE.ExtrudeGeometry( drawingData.currentShape, extrudeSettings );

        const M1 = new THREE.Matrix3().getInverse(M)


        for (let g = 0; g < geometry.vertices.length; g++){
          geometry.vertices[g].applyMatrix3(M1).add(p0)
          }

        var material = new THREE.MeshBasicMaterial( { color: 0x4e42f5 } );
        var mesh = new THREE.Mesh( geometry, material ) ;



        // update de la scene
        scene.add( mesh );
        drawingData.drawingObjects.push(mesh);
        // reinitalisation
        drawingData.currentShape = new THREE.Shape();
        drawingData.drawing3DPoints = [];
      }




    },

  };
})();
