const utilsData = (function() {
  return {
    enterMode: function(drawingData, mode){
      switch(mode){
        case "removeMode":
          drawingData.removeMode = true;
          drawingData.finMode = false;
          drawingData.bodyMode = false;
          drawingData.jawMode = false;
        break;
        case "finMode":
          drawingData.removeMode = false;
          drawingData.finMode = true;
          drawingData.bodyMode = false;
          drawingData.jawMode = false;
        break;
        case "bodyMode":
          drawingData.removeMode = false;
          drawingData.finMode = false;
          drawingData.bodyMode = true;
          drawingData.jawMode = false;
        break;
        case "jawMode":
          drawingData.removeMode = false;
          drawingData.finMode = false;
          drawingData.bodyMode = false;
          drawingData.jawMode = true;
        break;
      }
    },
  };
})();
